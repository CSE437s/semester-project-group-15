//
//  FullTestSessionView.swift
//  spaiDemo2
//
//  Created by Junyeong Jo on 2/23/24.
// not using this file

import SwiftUI

//struct FullTestSessionView: View {
//    @State private var currentTestIndex = 0
//    private let testViews: [AnyView] = [
//        AnyView(ShortDescriptionTestView()),
//        AnyView(SharingExperienceTestView()),
//        AnyView(ListeningComprehensionTestView()),
//        AnyView(ExpressingOpinionTestView())
//    ]
//
//    var body: some View {
//        VStack {
//            if currentTestIndex < testViews.count {
//                testViews[currentTestIndex]
//            } else {
//                Text("Test Completed")
//                // You might want to add a button or link to go back to the main menu or show the results.
//            }
//        }
//        .onAppear {
//            // Initialize anything you need for the test session
//        }
//        .navigationBarItems(trailing: Button(action: {
//            // Move to the next test or finish the session
//            if currentTestIndex < testViews.count - 1 {
//                currentTestIndex += 1
//            }
//        }) {
//            Text(currentTestIndex < testViews.count - 1 ? "Next" : "Finish")
//        })
//    }
//}


//#Preview {
//    FullTestSessionView()
//}
